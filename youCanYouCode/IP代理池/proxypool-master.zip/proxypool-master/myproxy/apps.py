from django.apps import AppConfig


class MyproxyConfig(AppConfig):
    name = 'myproxy'
